/* ============================================================
   Shortlist — fully integrated dashboard JS
   Uses localStorage for all persistence (demo mode).
   Connects to Lemma SDK when available as enhancement layer.
   ============================================================ */

/* ── 1. fadeUp reveal ── */
(function () {
  var els = Array.prototype.slice.call(document.querySelectorAll('.fade-up'));
  if (!els.length) return;
  var seen = new Map();
  var io = new IntersectionObserver(function (entries) {
    entries.forEach(function (e) {
      if (!e.isIntersecting) return;
      var el = e.target, parent = el.parentElement;
      var i = seen.get(parent) || 0;
      seen.set(parent, i + 1);
      el.style.transitionDelay = (i * 0.08) + 's';
      el.classList.add('in');
      io.unobserve(el);
    });
  }, { threshold: 0.08, rootMargin: '-100px 0px' });
  els.forEach(function (el) { io.observe(el); });
})();

/* ── 2. Mission: scroll-driven word-by-word reveal ── */
(function () {
  var nodes = document.querySelectorAll('[data-reveal]');
  if (!nodes.length) return;
  var P1 = "Shortlist is a job-application command centre for a final-year student applying to many roles.";
  var P2 = "Upload your resume and paste a job description, and an agent returns a verdict with the exact requirements quoted.";
  nodes.forEach(function (node, idx) {
    var text = idx === 0 ? P1 : P2;
    var hl = (node.getAttribute('data-hl') || '').split(',').filter(Boolean);
    var parts = text.split(' ');
    node.innerHTML = '';
    parts.forEach(function (word, i) {
      var span = document.createElement('span');
      span.className = 'mw';
      var clean = word.replace(/[^a-zA-Z]/g, '').toLowerCase();
      if (hl.indexOf(clean) !== -1) span.dataset.hl = '1';
      span.textContent = word + (i < parts.length - 1 ? ' ' : '');
      node.appendChild(span);
    });
  });
  var words = Array.prototype.slice.call(document.querySelectorAll('.mw'));
  function update() {
    var vh = window.innerHeight;
    words.forEach(function (w) {
      var r = w.getBoundingClientRect();
      var p = Math.min(1, Math.max(0, (vh * 0.95 - r.top) / (vh * 0.30)));
      w.style.opacity = (0.15 + p * 0.85).toFixed(3);
      if (w.dataset.hl) w.classList.toggle('hl-on', p > 0.6);
    });
  }
  window.addEventListener('scroll', update, { passive: true });
  window.addEventListener('resize', update, { passive: true });
  update();
})();

/* ── 3. HLS ── */
(function () {
  var vids = document.querySelectorAll('video[data-hls]');
  if (!vids.length) return;
  vids.forEach(function (video) {
    var SRC = video.getAttribute('data-hls');
    if (window.Hls && window.Hls.isSupported()) {
      var hls = new window.Hls();
      hls.loadSource(SRC);
      hls.attachMedia(video);
      hls.on(window.Hls.Events.MANIFEST_PARSED, function () { video.play().catch(function () {}); });
    } else if (video.canPlayType('application/vnd.apple.mpegurl')) {
      video.src = SRC;
      video.addEventListener('loadedmetadata', function () { video.play().catch(function () {}); });
    }
  });
})();

/* ── 4. Generic "navigate on submit" forms ── */
(function () {
  document.querySelectorAll('form[data-go]').forEach(function (f) {
    f.addEventListener('submit', function (e) {
      e.preventDefault();
      window.location.href = f.getAttribute('data-go');
    });
  });
})();

/* ── 5. Login form (standalone pages) ── */
(function () {
  var form = document.getElementById('auth-form');
  if (!form) return;
  var err = document.getElementById('auth-err');
  var emailRe = /^[^@\s]+@[^@\s]+\.[^@\s]+$/;
  function fail(msg) { if (err) { err.textContent = msg; err.style.display = 'block'; } }
  form.addEventListener('submit', function (e) {
    e.preventDefault();
    var email = form.email.value.trim();
    var pw = form.password.value;
    if (!emailRe.test(email)) return fail('Enter a valid email address.');
    if (pw.length < 6) return fail('Password must be at least 6 characters.');
    try { localStorage.setItem('sl_user', JSON.stringify({ email: email, name: email.split('@')[0] })); } catch (_) {}
    window.location.href = 'dashboard.html';
  });
})();

/* ── 6. Dashboard (full local + Lemma integration) ── */
(function () {
  var app = document.getElementById('app');
  if (!app) return;

  /* ================================================================
     LOCAL STORAGE DB
     ================================================================ */
  var DB = {
    _key: function (k) { return 'sl_' + k; },
    get: function (k, fallback) {
      try { var v = localStorage.getItem(this._key(k)); return v ? JSON.parse(v) : fallback; }
      catch (_) { return fallback; }
    },
    set: function (k, v) {
      try { localStorage.setItem(this._key(k), JSON.stringify(v)); } catch (_) {}
    },
    remove: function (k) {
      try { localStorage.removeItem(this._key(k)); } catch (_) {}
    }
  };

  /* ================================================================
     AUTH / LOGIN GATE
     ================================================================ */
  var currentUser = DB.get('user', null);

  function showLogin() {
    window.location.href = 'login.html';
  }

  function hideLogin() {
    // No-op for compatibility
  }

  function applyUser() {
    if (!currentUser) return;
    var greet = document.getElementById('greeting');
    var uname = document.getElementById('user-name');
    var ini = document.getElementById('user-ini');
    if (greet) greet.textContent = 'Welcome back, ' + currentUser.name;
    if (uname) uname.textContent = currentUser.name;
    if (ini) ini.textContent = (currentUser.name.slice(0,2) || 'SL').toUpperCase();
    // Populate settings
    var sn = document.getElementById('setting-name');
    var se = document.getElementById('setting-email');
    if (sn) sn.value = currentUser.name;
    if (se) se.value = currentUser.email;
  }

  // Check login state
  if (!currentUser) {
    showLogin();
  } else {
    applyUser();
  }

  /* ================================================================
     APPLICATION DATA (localStorage)
     ================================================================ */
  function getApplications() { return DB.get('applications', []); }
  function saveApplications(apps) { DB.set('applications', apps); }
  function addApplication(row) {
    var apps = getApplications();
    row.id = row.id || ('app_' + Date.now() + '_' + Math.random().toString(36).slice(2,6));
    row.created_at = row.created_at || new Date().toISOString();
    apps.unshift(row);
    saveApplications(apps);
    return row;
  }
  function updateApplication(id, updates) {
    var apps = getApplications();
    for (var i = 0; i < apps.length; i++) {
      if (apps[i].id === id) {
        Object.assign(apps[i], updates);
        break;
      }
    }
    saveApplications(apps);
  }

  function getResume() { return DB.get('resume', null); }
  function saveResume(text) { DB.set('resume', text); }

  /* ================================================================
     STATE
     ================================================================ */
  var VIDEOS = [];
  var NEWS = [];

  function escHtml(s) {
    var d = document.createElement('div');
    d.textContent = s || '';
    return d.innerHTML;
  }

  function asArray(v) {
    if (Array.isArray(v)) return v;
    if (typeof v === "string" && v.trim()) { try { var p = JSON.parse(v); return Array.isArray(p) ? p : []; } catch (e) { return []; } }
    return [];
  }

  function verdictClass(v) {
    if (v === 'STRONG FIT') return 'verdict-strong';
    if (v === 'STRETCH') return 'verdict-stretch';
    if (v === 'SKIP') return 'verdict-skip';
    return '';
  }

  /* ================================================================
     UI BUILDERS
     ================================================================ */
  function applicationCard(v) {
    var el = document.createElement('div');
    el.className = 'vid-card';
    var vc = verdictClass(v.verdict);
    el.innerHTML =
      '<div class="vid-thumb-wrap app-card-thumb ' + vc + '">' +
        '<div class="app-card-verdict">' +
          '<span class="verdict-badge ' + vc + '">' + escHtml(v.verdict || 'N/A') + '</span>' +
          '<span class="verdict-score">' + (Number(v.score)||0).toFixed(1) + '</span>' +
        '</div>' +
        '<div class="app-card-company">' + escHtml(v.company || '') + '</div>' +
        '<span class="vid-dur">' + escHtml(v.status || 'Evaluated') + '</span>' +
      '</div>' +
      '<div class="vid-meta"><h3>' + escHtml(v.role || '') + '</h3>' +
      '<span>' + escHtml(v.company || '') + '</span></div>';
    el.addEventListener('click', function () { openPlayerFromRow(v); });
    return el;
  }

  function newsletterItem(v, n) {
    var el = document.createElement('div');
    el.className = 'nl-item';
    var gaps = asArray(v.gaps);
    var gapText = gaps.length ? gaps[0] : 'Strong match waiting for review.';
    el.innerHTML =
      '<div class="nl-num">' + String(n).padStart(2, '0') + '</div>' +
      '<div class="nl-body">' +
        '<h3>' + escHtml(v.role + ', ' + v.company) + '</h3>' +
        '<p class="excerpt">' + escHtml(gapText) + '</p>' +
        '<div class="meta"><span>' + escHtml(v.company) + '</span><span>' + escHtml(v.dateStr || '') + '</span><span>Score: ' + (Number(v.score)||0).toFixed(1) + '</span></div>' +
      '</div>';
    el.addEventListener('click', function () { openReaderFromRow(v); });
    return el;
  }

  /* ================================================================
     VIEW SWITCHING
     ================================================================ */
  var views = document.querySelectorAll('.view');
  function showView(name) {
    views.forEach(function (vw) { vw.classList.toggle('hidden', vw.dataset.view !== name); });
    document.querySelectorAll('.side-link').forEach(function (l) {
      l.classList.toggle('active', l.dataset.tab === name);
    });
    if (['home', 'watch', 'newsletters', 'bookmarks', 'settings'].indexOf(name) !== -1) {
      DB.set('tab', name);
    }
    window.scrollTo(0, 0);
  }

  document.querySelectorAll('.side-link').forEach(function (l) {
    if (!l.dataset.tab) return;
    l.addEventListener('click', function () { showView(l.dataset.tab); });
  });

  /* ================================================================
     DETAIL VIEWS
     ================================================================ */
  function openPlayerFromRow(row) {
    var pt = document.getElementById('player-title');
    if (pt) pt.textContent = row.role + ', ' + row.company;
    var pa = document.getElementById('player-author');
    if (pa) pa.innerHTML = '<span class="verdict-badge ' + verdictClass(row.verdict) + '">' + escHtml(row.verdict || '') + '</span> (' + (Number(row.score)||0).toFixed(1) + ') &mdash; Status: ' + escHtml(row.status || 'Evaluated');
    var pd = document.getElementById('player-desc');
    if (pd) {
      pd.innerHTML = '';
      var proof = asArray(row.proof);
      if (proof.length) {
        var h = document.createElement('h3');
        h.textContent = 'Requirements Matched (' + proof.length + ')';
        h.style.cssText = 'margin-bottom:0.75rem; font-size:1rem; color:hsl(var(--foreground));';
        pd.appendChild(h);
        proof.forEach(function (p) {
          var item = document.createElement('div');
          item.className = 'proof-item';
          item.innerHTML = '<div class="proof-req">' + escHtml(p.requirement) + '</div><div class="proof-arrow">&rarr;</div><div class="proof-evidence">"' + escHtml(p.resume_evidence) + '"</div>';
          pd.appendChild(item);
        });
      }
      var gaps = asArray(row.gaps);
      if (gaps.length) {
        var gh = document.createElement('h3');
        gh.textContent = 'Gaps (' + gaps.length + ')';
        gh.style.cssText = 'margin-top:1.5rem; margin-bottom:0.75rem; font-size:1rem; color:hsl(var(--foreground));';
        pd.appendChild(gh);
        gaps.forEach(function (g) {
          var item = document.createElement('div');
          item.className = 'gap-item';
          item.textContent = g;
          pd.appendChild(item);
        });
      }
      if (row.draft_message) {
        var dh = document.createElement('h3');
        dh.textContent = 'Draft Intro';
        dh.style.cssText = 'margin-top:1.5rem; margin-bottom:0.75rem; font-size:1rem; color:hsl(var(--foreground));';
        pd.appendChild(dh);
        var dp = document.createElement('p');
        dp.style.cssText = 'line-height:1.7; color:hsl(var(--secondary-foreground)); font-style:italic; padding:1rem; background:hsl(var(--card)); border-radius:8px; border:1px solid hsl(var(--border)/0.4);';
        dp.textContent = row.draft_message;
        pd.appendChild(dp);
      }
      if (row.verified) {
        var badge = document.createElement('div');
        badge.className = 'verified-badge';
        badge.innerHTML = '&#10004; Citations Verified';
        pd.appendChild(badge);
      }
    }
    showView('player');
  }

  function openReaderFromRow(row) {
    document.getElementById('reader-kicker').textContent = row.verdict || 'STRETCH';
    document.getElementById('reader-kicker').className = 'kicker ' + verdictClass(row.verdict);
    document.getElementById('reader-title').textContent = row.role + ', ' + row.company;
    document.getElementById('reader-meta').innerHTML = '<span>' + escHtml(row.company) + '</span><span>' + escHtml(row.dateStr || '') + '</span><span>Score: ' + (Number(row.score)||0).toFixed(1) + '</span>';
    var body = document.getElementById('reader-body');
    body.innerHTML = '';
    var proof = asArray(row.proof);
    var gaps = asArray(row.gaps);
    if (proof.length) {
      var ph = document.createElement('h3'); ph.textContent = 'Requirements Matched'; ph.style.cssText = 'font-size:1rem; margin-bottom:0.75rem;'; body.appendChild(ph);
      proof.forEach(function (p) {
        var el = document.createElement('div'); el.className = 'proof-item';
        el.innerHTML = '<div class="proof-req">' + escHtml(p.requirement) + '</div><div class="proof-arrow">&rarr;</div><div class="proof-evidence">"' + escHtml(p.resume_evidence) + '"</div>';
        body.appendChild(el);
      });
    }
    if (gaps.length) {
      var gh = document.createElement('h3'); gh.textContent = 'Gaps Identified'; gh.style.cssText = 'font-size:1rem; margin-top:1.5rem; margin-bottom:0.75rem;'; body.appendChild(gh);
      gaps.forEach(function (g) { var el = document.createElement('div'); el.className = 'gap-item'; el.textContent = g; body.appendChild(el); });
    }
    if (row.draft_message) {
      var dh = document.createElement('h3'); dh.textContent = 'Draft Intro'; dh.style.cssText = 'font-size:1rem; margin-top:1.5rem; margin-bottom:0.75rem;'; body.appendChild(dh);
      var dp = document.createElement('p'); dp.textContent = row.draft_message; dp.style.cssText = 'font-style:italic; padding:1rem; background:hsl(var(--card)); border-radius:8px; border:1px solid hsl(var(--border)/0.4);'; body.appendChild(dp);
    }
    // Approve / Discard buttons
    if (row.needs_review && (row.status === 'Evaluated' || !row.status)) {
      var bw = document.createElement('div'); bw.style.cssText = 'margin-top:2rem; display:flex; gap:1rem;';
      var ba = document.createElement('button'); ba.className = 'btn-primary'; ba.textContent = 'Approve & Apply';
      var br = document.createElement('button'); br.className = 'btn-glass liquid-glass'; br.textContent = 'Discard';
      ba.addEventListener('click', async function () {
        ba.disabled = true; ba.textContent = 'Approving...';
        updateApplication(row.id, { status: 'Applied', needs_review: false });
        if (window.client) { try { await window.client.records.update("applications", row.id, { status: "Applied", needs_review: false }); } catch(_){} }
        showToast('Application approved! Status: Applied.');
        document.querySelector('[data-back="newsletters"]').click();
        loadApplications();
      });
      br.addEventListener('click', async function () {
        br.disabled = true; br.textContent = 'Discarding...';
        updateApplication(row.id, { status: 'Discarded', needs_review: false });
        if (window.client) { try { await window.client.records.update("applications", row.id, { status: "Discarded", needs_review: false }); } catch(_){} }
        showToast('Application discarded.');
        document.querySelector('[data-back="newsletters"]').click();
        loadApplications();
      });
      bw.appendChild(ba); bw.appendChild(br); body.appendChild(bw);
    }
    showView('reader');
  }

  /* back buttons */
  document.querySelectorAll('[data-back]').forEach(function (b) {
    b.addEventListener('click', function () { showView(b.getAttribute('data-back')); });
  });

  /* logout */
  var logout = document.getElementById('logout');
  if (logout) logout.addEventListener('click', function () {
    DB.remove('user');
    currentUser = null;
    window.location.href = 'index.html';
  });

  /* ================================================================
     TOAST
     ================================================================ */
  function showToast(msg) {
    var existing = document.getElementById('sl-toast');
    if (existing) existing.remove();
    var t = document.createElement('div');
    t.id = 'sl-toast'; t.className = 'sl-toast'; t.textContent = msg;
    document.body.appendChild(t);
    requestAnimationFrame(function () { t.classList.add('show'); });
    setTimeout(function () { t.classList.remove('show'); setTimeout(function () { t.remove(); }, 400); }, 3000);
  }

  /* ================================================================
     RENDER
     ================================================================ */
  function loadApplications() {
    var apps = getApplications();
    VIDEOS = [];
    NEWS = [];
    apps.forEach(function (r) {
      var v = Object.assign({}, r, {
        dateStr: r.created_at ? new Date(r.created_at).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }) : ''
      });
      VIDEOS.push(v);
      if (r.needs_review && (r.status === 'Evaluated' || !r.status)) NEWS.push(v);
    });
    renderAll();
  }

  function renderAll() {
    var grid = document.getElementById('vid-grid');
    if (grid) {
      grid.innerHTML = '';
      if (VIDEOS.length > 0) VIDEOS.forEach(function (v) { grid.appendChild(applicationCard(v)); });
      else grid.innerHTML = '<div class="empty-state"><div class="empty-icon">&#128209;</div><p>No applications yet. Paste a job description on the Dashboard to get started.</p></div>';
    }
    var nlList = document.getElementById('nl-list');
    if (nlList) {
      nlList.innerHTML = '';
      if (NEWS.length > 0) NEWS.forEach(function (v, i) { nlList.appendChild(newsletterItem(v, i + 1)); });
      else nlList.innerHTML = '<div class="empty-state"><p>No STRETCH applications in the review queue yet.</p></div>';
    }
    var railV = document.getElementById('home-videos');
    if (railV) {
      railV.innerHTML = '';
      if (VIDEOS.length > 0) VIDEOS.slice(0, 4).forEach(function (v) { railV.appendChild(applicationCard(v)); });
      else railV.innerHTML = '<div style="opacity:0.5; padding:1rem 0; font-size:0.95rem;">No applications yet. Use the form above to evaluate a role.</div>';
    }
    var homeNl = document.getElementById('home-news');
    if (homeNl) {
      homeNl.innerHTML = '';
      if (NEWS.length > 0) NEWS.slice(0, 3).forEach(function (v, i) { homeNl.appendChild(newsletterItem(v, i + 1)); });
      else homeNl.innerHTML = '<div style="opacity:0.5; padding:1rem 0; font-size:0.95rem;">No review queue items yet.</div>';
    }
    // Update resume status on upload page
    updateResumeStatus();
  }

  loadApplications();
  showView(DB.get('tab', 'home'));

  /* ================================================================
     SEARCH
     ================================================================ */
  var searchInput = document.querySelector('.search-box input');
  if (searchInput) {
    searchInput.addEventListener('input', function () {
      var q = searchInput.value.toLowerCase().trim();
      if (!q) { loadApplications(); return; }
      var apps = getApplications();
      var filtered = apps.filter(function (a) {
        return (a.company || '').toLowerCase().indexOf(q) !== -1 ||
               (a.role || '').toLowerCase().indexOf(q) !== -1 ||
               (a.verdict || '').toLowerCase().indexOf(q) !== -1 ||
               (a.status || '').toLowerCase().indexOf(q) !== -1;
      });
      VIDEOS = filtered.map(function (r) { return Object.assign({}, r, { dateStr: r.created_at ? new Date(r.created_at).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }) : '' }); });
      NEWS = VIDEOS.filter(function (r) { return r.needs_review && (r.status === 'Evaluated' || !r.status); });
      renderAll();
    });
  }

  /* ================================================================
     RESUME UPLOAD
     ================================================================ */
  function updateResumeStatus() {
    var statusEl = document.getElementById('upload-status');
    if (!statusEl) return;
    var resume = getResume();
    if (resume) {
      statusEl.className = 'upload-status success';
      statusEl.innerHTML = '&#10004; Resume uploaded and ready (' + (resume.length / 1024).toFixed(1) + ' KB). The agent will use it for all matches.';
    } else {
      statusEl.className = 'upload-status warning';
      statusEl.innerHTML = '&#9888; No resume uploaded yet. Upload one to start matching.';
    }
    updateRunHint();
  }

  function updateRunHint() {
    var hint = document.getElementById('run-hint');
    if (!hint) return;
    if (!getResume()) {
      hint.innerHTML = '&#9888; Upload your resume first (Upload Resume tab).';
      hint.style.color = 'hsl(40 90% 55%)';
    } else {
      hint.textContent = 'Matches the JD against your resume and writes a verdict.';
      hint.style.color = '';
    }
  }

  // Wire upload
  (function () {
    var uploadBtn = document.querySelector('#upload-form .btn-primary');
    var fileInput = document.getElementById('resume-file');
    var dropzone = document.getElementById('upload-dropzone');
    var selectedFileEl = document.getElementById('selected-file');
    if (!uploadBtn || !fileInput) return;

    fileInput.addEventListener('change', function () {
      if (fileInput.files[0] && selectedFileEl)
        selectedFileEl.textContent = 'Selected: ' + fileInput.files[0].name + ' (' + (fileInput.files[0].size / 1024).toFixed(1) + ' KB)';
    });

    if (dropzone) {
      dropzone.addEventListener('dragover', function (e) { e.preventDefault(); dropzone.classList.add('drag-over'); });
      dropzone.addEventListener('dragleave', function () { dropzone.classList.remove('drag-over'); });
      dropzone.addEventListener('drop', function (e) {
        e.preventDefault(); dropzone.classList.remove('drag-over');
        if (e.dataTransfer.files.length) { fileInput.files = e.dataTransfer.files; fileInput.dispatchEvent(new Event('change')); }
      });
    }

    uploadBtn.addEventListener('click', async function () {
      var file = fileInput.files[0];
      if (!file) { showToast('Please select a file first.'); return; }
      uploadBtn.disabled = true; uploadBtn.textContent = 'Uploading...';
      var statusEl = document.getElementById('upload-status');
      if (statusEl) { statusEl.className = 'upload-status'; statusEl.innerHTML = '<span class="step-spinner"></span> Reading file...'; }
      try {
        var text = await file.text();
        if (statusEl) statusEl.innerHTML = '<span class="step-spinner"></span> Saving resume...';
        // Save locally
        saveResume(text);
        // Also try Lemma upload if available
        if (window.client && window.client.files) {
          try { await window.client.files.upload('/resume/cv.md', text, { contentType: 'text/markdown' }); } catch(_) {}
        }
        if (statusEl) { statusEl.className = 'upload-status success'; statusEl.innerHTML = '&#10004; Resume uploaded successfully! (' + (text.length / 1024).toFixed(1) + ' KB)'; }
        uploadBtn.textContent = 'Re-upload';
        updateRunHint();
        showToast('Resume uploaded and ready for matching.');
      } catch (e) {
        if (statusEl) { statusEl.className = 'upload-status error'; statusEl.innerHTML = '&#10006; Upload failed: ' + escHtml(e.message || String(e)); }
        uploadBtn.textContent = 'Retry Upload';
      }
      uploadBtn.disabled = false;
    });
  })();

  /* ================================================================
     SETTINGS
     ================================================================ */
  var saveBtn = document.querySelector('.settings-form .btn-primary');
  if (saveBtn) {
    saveBtn.addEventListener('click', function () {
      var name = (document.getElementById('setting-name').value || '').trim();
      var email = (document.getElementById('setting-email').value || '').trim();
      if (name && email) {
        currentUser = Object.assign(currentUser || {}, { name: name, email: email });
        DB.set('user', currentUser);
        applyUser();
        showToast('Preferences saved.');
      }
    });
  }

  /* ================================================================
     THINKING INDICATOR
     ================================================================ */
  function showThinking(container) {
    var el = document.createElement('div');
    el.className = 'thinking-indicator'; el.id = 'thinking-indicator';
    el.innerHTML = '<div class="thinking-header"><div class="thinking-pulse"></div><span>Agent is working...</span></div><div class="thinking-steps" id="thinking-steps"></div>';
    container.appendChild(el);
    return el;
  }

  function addThinkingStep(text, done) {
    var steps = document.getElementById('thinking-steps');
    if (!steps) return;
    var pending = steps.querySelectorAll('.thinking-step.pending');
    if (done && pending.length > 0) {
      var last = pending[pending.length - 1];
      last.classList.remove('pending'); last.classList.add('done');
      last.querySelector('.step-icon').innerHTML = '&#10004;';
    }
    if (text) {
      var step = document.createElement('div');
      step.className = 'thinking-step' + (done ? ' done' : ' pending');
      step.innerHTML = '<span class="step-icon">' + (done ? '&#10004;' : '<span class="step-spinner"></span>') + '</span><span>' + escHtml(text) + '</span>';
      steps.appendChild(step);
    }
  }

  function removeThinking() {
    var el = document.getElementById('thinking-indicator');
    if (el) el.remove();
  }

  /* ================================================================
     RUN MATCH
     ================================================================ */
  var runBtn = document.getElementById('run');
  if (runBtn) runBtn.addEventListener('click', runMatch);

  async function runMatch() {
    var company = document.getElementById('company').value.trim();
    var role = document.getElementById('role').value.trim();
    var jd = document.getElementById('jd').value.trim();
    var btn = document.getElementById('run');
    var hint = document.getElementById('run-hint');
    var resDiv = document.getElementById('result');

    if (!jd) { hint.textContent = 'Paste a job description first.'; hint.style.color = 'hsl(0 70% 55%)'; return; }
    if (!getResume()) {
      hint.innerHTML = '&#9888; Upload your resume first (Upload Resume tab).';
      hint.style.color = 'hsl(40 90% 55%)';
      showToast('Please upload your resume before running a match.');
      return;
    }

    btn.disabled = true;
    btn.querySelector('span').textContent = 'Matching...';
    btn.classList.add('btn-loading');
    resDiv.innerHTML = '';
    showThinking(resDiv);
    addThinkingStep('Sending JD to matcher agent...', false);

    var message = "Company: " + (company || "(infer from JD)") + "\nRole: " + (role || "(infer from JD)") + "\n\nJob description:\n" + jd;
    var usedLemma = false;

    try {
      if (!window.client || !window.client.agents) {
         throw new Error("Backend not initialized. Please ensure you are logged in via Lemma.");
      }
      
      addThinkingStep('Sending JD to matcher agent...', true);
      addThinkingStep('Searching resume for matching evidence...', false);
      
      // Call the REAL Lemma agent
      await window.client.agents.run("matcher", message, { title: (company || "Role") + " - match" });
      
      addThinkingStep('Searching resume for matching evidence...', true);
      addThinkingStep('Loading results from server...', false);
      
      // Wait a moment for the DB to sync
      await sleep(1500);
      
      // Load from Lemma table
      var resp = await window.client.records.list("applications", { limit: 1, sort: [{ field: "created_at", direction: "desc" }] });
      var rows = resp.items || resp || [];
      if (rows.length) {
        var r = rows[0];
        var row = { id: r.id, company: r.company, role: r.role, verdict: r.verdict, score: r.score, status: r.status || 'Evaluated', proof: r.proof, gaps: r.gaps, draft_message: r.draft_message, needs_review: r.needs_review, verified: r.verified };
        addApplication(row); // Save to local cache too
      } else {
        throw new Error("Agent finished but no application record was found.");
      }
      addThinkingStep('Loading results from server...', true);

      loadApplications();
      removeThinking();
      // Show inline verdict card
      var latest = getApplications()[0];
      if (latest) renderVerdictCard(resDiv, latest);
      document.getElementById('jd').value = '';
      document.getElementById('company').value = '';
      document.getElementById('role').value = '';
      showToast('Match complete!');

    } catch (e) {
      removeThinking();
      resDiv.innerHTML = '<div class="result-error">&#10006; Match failed: ' + escHtml(e.message || String(e)) + '</div>';
    } finally {
      btn.disabled = false;
      btn.querySelector('span').textContent = 'Run match';
      btn.classList.remove('btn-loading');
      hint.textContent = 'Matches the JD against your resume and writes a verdict.';
      hint.style.color = '';
    }
  }

  function sleep(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }

  /* ================================================================
     LOCAL MATCHER (demo fallback when Lemma agent unavailable)
     ================================================================ */
  function localMatcherEvaluate(company, role, jdText, resumeText) {
    company = company || inferField(jdText, 'company');
    role = role || inferField(jdText, 'role');
    var requirements = extractRequirements(jdText);
    var proof = [];
    var gaps = [];

    requirements.forEach(function (req) {
      var evidence = findEvidence(req, resumeText);
      if (evidence) {
        proof.push({ requirement: req, resume_evidence: evidence });
      } else {
        gaps.push(req + ' (No evidence in resume)');
      }
    });

    var matchRatio = requirements.length > 0 ? proof.length / requirements.length : 0;
    var score = Math.round((1 + matchRatio * 4) * 10) / 10;
    score = Math.min(5, Math.max(1, score));
    var verdict = score >= 4.0 ? 'STRONG FIT' : score >= 3.0 ? 'STRETCH' : 'SKIP';
    var needsReview = verdict === 'STRETCH';

    var draft = 'Hi ' + company + ' team, I noticed the ' + role + ' role. ' +
      (proof.length > 0 ? 'My experience includes ' + proof[0].resume_evidence.slice(0, 80) + '. ' : '') +
      'I would love to discuss how my background aligns with your needs.';

    return {
      company: company, role: role, jd_text: jdText, verdict: verdict, score: score,
      status: 'Evaluated', proof: proof, gaps: gaps, draft_message: draft,
      needs_review: needsReview, verified: true
    };
  }

  function extractRequirements(jd) {
    var reqs = [];
    var lines = jd.split('\n');
    lines.forEach(function (line) {
      line = line.replace(/^[\s\-\*\u2022\d.]+/, '').trim();
      if (line.length > 15 && line.length < 200) {
        // Looks like a requirement
        var lower = line.toLowerCase();
        if (lower.indexOf('experience') !== -1 || lower.indexOf('proficien') !== -1 ||
            lower.indexOf('knowledge') !== -1 || lower.indexOf('ability') !== -1 ||
            lower.indexOf('skill') !== -1 || lower.indexOf('familiar') !== -1 ||
            lower.indexOf('understand') !== -1 || lower.indexOf('year') !== -1 ||
            lower.indexOf('degree') !== -1 || lower.indexOf('work with') !== -1 ||
            lower.indexOf('develop') !== -1 || lower.indexOf('design') !== -1 ||
            lower.indexOf('build') !== -1 || lower.indexOf('manage') !== -1 ||
            lower.indexOf('lead') !== -1 || lower.indexOf('strong') !== -1 ||
            lower.indexOf('excellent') !== -1) {
          reqs.push(line);
        }
      }
    });
    // If we found too few, just grab substantial lines
    if (reqs.length < 3) {
      lines.forEach(function (line) {
        line = line.replace(/^[\s\-\*\u2022\d.]+/, '').trim();
        if (line.length > 20 && line.length < 200 && reqs.indexOf(line) === -1) {
          reqs.push(line);
        }
      });
    }
    return reqs.slice(0, 12);
  }

  function findEvidence(requirement, resume) {
    if (!resume) return null;
    // Extract keywords from the requirement
    var keywords = requirement.toLowerCase().replace(/[^a-z0-9\s]/g, '').split(/\s+/).filter(function (w) {
      return w.length > 3 && ['with', 'that', 'this', 'have', 'from', 'will', 'been', 'more', 'than', 'also', 'such', 'they', 'their', 'about', 'would', 'could', 'should', 'which', 'experience', 'ability', 'strong', 'excellent'].indexOf(w) === -1;
    });
    if (keywords.length === 0) return null;
    var lines = resume.split('\n');
    var bestLine = null;
    var bestScore = 0;
    lines.forEach(function (line) {
      if (line.trim().length < 10) return;
      var lower = line.toLowerCase();
      var score = 0;
      keywords.forEach(function (kw) {
        if (lower.indexOf(kw) !== -1) score++;
      });
      if (score > bestScore) { bestScore = score; bestLine = line.trim(); }
    });
    // Need at least 1 keyword match
    return bestScore >= 1 ? bestLine : null;
  }

  function inferField(jd, field) {
    if (field === 'company') {
      var match = jd.match(/(?:at|@|company[:\s]*|join[:\s]*)\s*([A-Z][A-Za-z0-9\s&.]+)/);
      return match ? match[1].trim().slice(0, 30) : 'Company';
    }
    if (field === 'role') {
      var match2 = jd.match(/(?:role|position|title|hiring)[:\s]*([^\n]{5,50})/i);
      return match2 ? match2[1].trim() : 'Role';
    }
    return '';
  }

  /* ================================================================
     VERDICT CARD (inline result)
     ================================================================ */
  function renderVerdictCard(container, row) {
    var proof = asArray(row.proof);
    var gaps = asArray(row.gaps);
    var vc = verdictClass(row.verdict);
    var html =
      '<div class="verdict-card ' + vc + '">' +
        '<div class="vc-header">' +
          '<div class="vc-verdict-wrap"><span class="verdict-badge big ' + vc + '">' + escHtml(row.verdict || '') + '</span><span class="vc-score">' + (Number(row.score)||0).toFixed(1) + ' / 5</span></div>' +
          '<div class="vc-role">' + escHtml(row.role) + ' at ' + escHtml(row.company) + '</div>' +
        '</div>';
    if (proof.length) {
      html += '<div class="vc-section"><div class="vc-section-title">Matched (' + proof.length + ')</div>';
      proof.forEach(function (p) { html += '<div class="proof-item"><div class="proof-req">' + escHtml(p.requirement) + '</div><div class="proof-arrow">&rarr;</div><div class="proof-evidence">"' + escHtml(p.resume_evidence) + '"</div></div>'; });
      html += '</div>';
    }
    if (gaps.length) {
      html += '<div class="vc-section"><div class="vc-section-title">Gaps (' + gaps.length + ')</div>';
      gaps.forEach(function (g) { html += '<div class="gap-item">' + escHtml(g) + '</div>'; });
      html += '</div>';
    }
    if (row.draft_message) html += '<div class="vc-section"><div class="vc-section-title">Draft Intro</div><p class="vc-draft">' + escHtml(row.draft_message) + '</p></div>';
    html += '</div>';
    container.innerHTML = html;
  }

  /* ================================================================
     LEMMA SDK BOOT (Required for Backend)
     ================================================================ */
  window.boot = async function () {
    try {
      window.client = new window.LemmaClient.LemmaClient();
      var state = await window.client.initialize({ requireAuth: true });
      
      // Sync Lemma user info to local storage
      if (state.user) {
        var name = state.user.name || (state.user.email ? state.user.email.split('@')[0] : null);
        if (name && currentUser) {
          currentUser.name = name;
          if (state.user.email) currentUser.email = state.user.email;
          DB.set('user', currentUser);
          applyUser();
        }
      }
      // Try loading remote applications too
      try {
        var resp = await window.client.records.list("applications", { limit: 100, sort: [{ field: "created_at", direction: "desc" }] });
        var rows = resp.items || resp || [];
        if (rows.length > 0) {
          // Merge remote into local (avoid dupes by id)
          var local = getApplications();
          var localIds = {};
          local.forEach(function (a) { localIds[a.id] = true; });
          rows.forEach(function (r) {
            if (!localIds[r.id]) {
              local.push({ id: r.id, company: r.company, role: r.role, verdict: r.verdict, score: r.score, status: r.status || 'Evaluated', proof: r.proof, gaps: r.gaps, draft_message: r.draft_message, needs_review: r.needs_review, verified: r.verified, created_at: r.created_at });
            }
          });
          local.sort(function (a, b) { return (b.created_at || '').localeCompare(a.created_at || ''); });
          saveApplications(local);
          loadApplications();
        }
      } catch (_) {}
      try { window.client.datastore.watchChanges({ onChange: function () { /* Could sync here */ } }); } catch (_) {}
      showToast('Connected to Shortlist cloud.');
    } catch (e) {
      console.log('Lemma SDK not available, running in local demo mode.', e);
    }
  };

})();